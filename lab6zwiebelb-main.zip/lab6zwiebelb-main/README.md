# lab6-starter
1) There are 2427 lines, 306281 words, and 2158046 characters in xkcd.json
2) lab6