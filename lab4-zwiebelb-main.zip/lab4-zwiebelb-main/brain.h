#ifndef BRAIN_H
#define BRAIN_H

#include "three_mens_morris.h"

Move GalaxyBrain(int phase, const Board board);

#endif
